import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { JHS_PREVIEW_SOURCES } from '../services/content-store/jhs-representative-preview.ts';

const toolRoot = process.env.FILUMIRE_PDF_TOOLS ?? 'C:/Users/tabi/AppData/Local/Temp/filumire-b7-pdf-tools/node_modules';
const { getDocument } = await import(pathToFileURL(path.join(toolRoot, 'pdfjs-dist/legacy/build/pdf.mjs')).href);
const { createCanvas } = await import(pathToFileURL(path.join(toolRoot, '@napi-rs/canvas/index.js')).href);
const sourceRoot = process.env.FILUMIRE_CCP_SOURCE_ROOT ?? JSON.parse(fs.readFileSync('docs/jhs-development/lineage-manifest.json')).sourcePdfRoot;
const output = 'docs/jhs-development/preview-source-review';
fs.mkdirSync(output, { recursive: true });
const documents = new Map(), loadingTasks = [], pages = new Map(), results = [];
try {
  for (const row of JHS_PREVIEW_SOURCES) {
    const source = row.source;
    if (!documents.has(source.documentId)) {
      const bytes = fs.readFileSync(path.join(sourceRoot, path.basename(source.localPath)));
      assert.equal(createHash('sha256').update(bytes).digest('hex'), source.sha256);
      const task = getDocument({ data: new Uint8Array(bytes), useSystemFonts: true, isEvalSupported: false,
        standardFontDataUrl: pathToFileURL(path.join(toolRoot, 'pdfjs-dist/standard_fonts/')).href,
        wasmUrl: pathToFileURL(path.join(toolRoot, 'pdfjs-dist/wasm/')).href });
      loadingTasks.push(task);
      const pdf = await task.promise;
      documents.set(source.documentId, pdf);
    }
    const pdfPage = source.pdfPages[0], key = `${source.documentId}-${pdfPage}`;
    if (!pages.has(key)) {
      const page = await documents.get(source.documentId).getPage(pdfPage);
      const text = (await page.getTextContent()).items.map(i => i.str ?? '').join(' ');
      const viewport = page.getViewport({ scale: 1.2 }), canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
      await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
      fs.writeFileSync(`${output}/${key}.png`, canvas.toBuffer('image/png'));
      fs.writeFileSync(`${output}/${key}.txt`, text);
      pages.set(key, text);
    }
    assert(pages.get(key).replace(/\s/g, '').includes(row.officialCode.replace(/\s/g, '')), `Printed code absent on pinned page: ${row.id}`);
    results.push({ competencyId: row.id, officialCodeAsPrinted: row.officialCode, sha256: source.sha256, localPath: path.join(sourceRoot, path.basename(source.localPath)), pdfPage, renderedPage: `${output}/${key}.png`, printedCodeVerified: true, sourceIssueIds: [...row.sourceIssueIds, ...row.globalSourceIssueIds], educationalApproval: 'pending' });
  }
  fs.writeFileSync(`${output}/results.json`, JSON.stringify(results, null, 2) + '\n');
  console.log(`PASS ${results.length} literal indicator codes on ${pages.size} rendered source pages; ${documents.size} pinned PDF hashes. Pedagogical approval remains pending.`);
} finally {
  for (const task of loadingTasks) await task.destroy();
}
